import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='yunwltn',
    application_name='aws-movie-flask-app',
    app_uid='JCNyDQBrLTz8z9MNft',
    org_uid='7d336eb5-da3b-481c-9c39-abccaa116da1',
    deployment_uid='853b2a7f-e3e4-4eac-9e4e-a72197dcf215',
    service_name='aws-movie-flask-app',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='6.2.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'aws-movie-flask-app-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
